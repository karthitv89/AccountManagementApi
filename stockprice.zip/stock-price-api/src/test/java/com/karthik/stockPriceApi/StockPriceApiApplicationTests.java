package com.karthik.stockPriceApi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StockPriceApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
