package com.karthik.stockPriceApi;

public class AppConstants {
    public static String TREND_UP = "UP";
    public static String TREND_DOWN = "DOWN";
}
