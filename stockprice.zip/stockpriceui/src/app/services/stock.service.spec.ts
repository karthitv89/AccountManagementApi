import { StockService } from "./stock.service";
import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';

describe("StockService", () =>{
    let stockService : StockService,
        httpTestingController :  HttpTestingController;

    beforeEach(()=>{
        TestBed.configureTestingModule({
            imports:[HttpClientTestingModule],
            providers:[StockService]
        })
    });
 it ('get latest stock list', ()=>{
    stockService.getUserRequests();
 });
});