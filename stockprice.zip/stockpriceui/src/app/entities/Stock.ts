import { TooltipRendererParams } from 'ag-grid-community'

export class Stock {
    symbol : string;
    price : number;
    trend : string;
    
}